/* This file is auto generated, version 202106272333 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202106272333 SMP Sun Jun 27 23:36:43 UTC 2021"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "kathleen"
#define LINUX_COMPILER "gcc (Ubuntu 10.3.0-4ubuntu1) 10.3.0, GNU ld (GNU Binutils for Ubuntu) 2.36.50.20210618"
